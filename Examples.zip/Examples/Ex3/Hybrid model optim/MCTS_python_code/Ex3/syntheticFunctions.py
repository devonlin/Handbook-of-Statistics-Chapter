# -*- coding: utf-8 -*-
#==========================================
# Title:  syntheticFunctions.py
# Author: Binxin Ru and Ahsan Alvi
# Date:   20 August 2019
# Link:   https://arxiv.org/abs/1906.08878
#==========================================

import numpy as np
import math as anita

# =============================================================================
# Rosenbrock Function (f_min = 0)
# https://www.sfu.ca/~ssurjano/rosen.html
# =============================================================================
def myrosenbrock(X):
    X = np.asarray(X)
    X = X.reshape((-1, 2))
   # print(len(X.shape))
    if len(X.shape) == 1:  # one observation
        x1 = X[0]
        x2 = X[1]
    else:  # multiple observations
        x1 = X[:, 0]
        x2 = X[:, 1]
    fx = 100 * (x2 - x1 ** 2) ** 2 + (x1 - 1) ** 2

    return fx.reshape(-1, 1) / 300

# =============================================================================
#  Six-hump Camel Function (f_min = - 1.0316 )
#  https://www.sfu.ca/~ssurjano/camel6.html       
# =============================================================================
def mysixhumpcamp(X):
    X = np.asarray(X)
    X = np.reshape(X, (-1, 2))
    if len(X.shape) == 1:
        x1 = X[0]
        x2 = X[1]
    else:
        x1 = X[:, 0]
        x2 = X[:, 1]
    term1 = (4 - 2.1 * x1 ** 2 + (x1 ** 4) / 3) * x1 ** 2
    term2 = x1 * x2
    term3 = (-4 + 4 * x2 ** 2) * x2 ** 2
    fval = term1 + term2 + term3
    return fval.reshape(-1, 1) / 10

# =============================================================================
# Beale function (f_min = 0)
# https://www.sfu.ca/~ssurjano/beale.html
# =============================================================================
def mybeale(X):
    X = np.asarray(X) / 2
    X = X.reshape((-1, 2))
    if len(X.shape) == 1:
        x1 = X[0] * 2
        x2 = X[1] * 2
    else:
        x1 = X[:, 0] * 2
        x2 = X[:, 1] * 2
    fval = (1.5 - x1 + x1 * x2) ** 2 + (2.25 - x1 + x1 * x2 ** 2) ** 2 + (
            2.625 - x1 + x1 * x2 ** 3) ** 2
    return fval.reshape(-1, 1) / 50


def func2C(ht_list, X):
    # ht is a categorical index
    # X is a continuous variable
    X = X * 2
    
    assert len(ht_list) == 2
    ht1 = ht_list[0]
    ht2 = ht_list[1]

    if ht1 == 0:  # rosenbrock
        f = myrosenbrock(X)
    elif ht1 == 1:  # six hump
        f = mysixhumpcamp(X)
    elif ht1 == 2:  # beale
        f = mybeale(X)

    if ht2 == 0:  # rosenbrock
        f = f + myrosenbrock(X)
    elif ht2 == 1:  # six hump
        f = f + mysixhumpcamp(X)
    else:
        f = f + mybeale(X)

    y = f + 1e-6 * np.random.rand(f.shape[0], f.shape[1])
    return y.astype(float)


def func3C(ht_list, X):
    # ht is a categorical index
    # X is a continuous variable
    X = np.atleast_2d(X)
    assert len(ht_list) == 3
    ht1 = ht_list[0]
    ht2 = ht_list[1]
    ht3 = ht_list[2]

    X = X * 2
    if ht1 == 0:  # rosenbrock
        f = myrosenbrock(X)
       # print(f)
    elif ht1 == 1:  # six hump
        f = mysixhumpcamp(X)
    elif ht1 == 2:  # beale
        f = mybeale(X)

    if ht2 == 0:  # rosenbrock
        f = f + myrosenbrock(X)
    elif ht2 == 1:  # six hump
        f = f + mysixhumpcamp(X)
    else:
        f = f + mybeale(X)

    if ht3 == 0:  # rosenbrock
        f = f + 5 * mysixhumpcamp(X)
    elif ht3 == 1:  # six hump
        f = f + 2 * myrosenbrock(X)
    else:
        f = f + ht3 * mybeale(X)

    y = f + 1e-6 * np.random.rand(f.shape[0], f.shape[1])

    return y.astype(float)


# =============================================================================
#  Ex1
# =============================================================================

def Ex1_1(X):
    X = np.asarray(X)
    X = X.reshape((-1,1))
    if len(X.shape) == 1:  
        x1 = X[0]
    else: 
        x1 = X[:,0]
    fx =2-anita.cos(2*anita.pi*x1)
    fx=np.asarray(fx)
    return fx.reshape((-1,1))


def Ex1_2(X):
    X = np.asarray(X)
    X = X.reshape((-1, 1))
    if len(X.shape) == 1:
        x1 = X[0]
    else: 
        x1 = X[:, 0]
    fx =1-anita.cos(4*anita.pi*x1)
    fx=np.asarray(fx)
    return fx.reshape(-1, 1)

def Ex1_3(X):
    X = np.asarray(X)
    X = X.reshape((-1, 1))
    if len(X.shape) == 1: 
        x1 = X[0]
    else: 
        x1 = X[:, 0]
    fx =anita.cos(2*anita.pi*x1)
    fx=np.asarray(fx)
    return fx.reshape(-1, 1)


def func(ht_list, X):
    assert len(ht_list) == 1
    ht1 = ht_list[0]
    if ht1 == 1: 
        f = Ex1_1(X)
    elif ht1 == 2:  
        f = Ex1_2(X)
    elif ht1 == 3:  
        f = Ex1_3(X)
    y = f

    return y.astype(float)



# =============================================================================
#  Ex2
# =============================================================================

def func2(ht_list, X):
    # Ensure X is a numpy array
    X = np.asarray(X)
    
    # Initialize f and g
    f = 0
    g = 0
    
    # Ensure ht_list has two categorical variables (this is like z in your R function)
    ht1, ht2 = ht_list
    x1, x2 = X  # Continuous variables
    
    # Compute f based on ht1 (first categorical variable)
    if ht1 == 1:
        f = x1 + x2 ** 2
    elif ht1 == 2:
        f = x1 ** 2 + x2
    elif ht1 == 3:
        f = x1 ** 2 + x2 ** 2
    
    # Compute g based on ht2 (second categorical variable)
    if ht2 == 1:
        g = np.cos(x1) + np.cos(x2 * 2)
    elif ht2 == 2:
        g = np.cos(2 * x1) + np.cos(x2)
    elif ht2 == 3:
        g = np.cos(x1 * 2) + np.cos(x2 * 2)
    
    # Final result is the sum of f and g
    y = f + g
    
    return np.array([y], dtype=float)  # Ensure the result is a numpy array with one value




# =============================================================================
#  Ex3
# =============================================================================

def func3(ht_list, X):
    # Ensure X is a numpy array
    X = np.asarray(X)
    f=0
    g=0
    h=0
    # Unpack continuous and categorical inputs
    x1, x2, x3 = X
    ht1, ht2, ht3 = ht_list
    
    # Compute f based on the first categorical variable (ht1)
    if ht1 == 1:
        f = x1 + x2 ** 2 + x3
    elif ht1 == 2:
        f = x1 ** 2 + x2 + x3
    elif ht1 == 3:
        f = x1 + x2 ** 2 + x3
    #else:
     #   raise ValueError("Invalid value for ht1. Expected 1, 2, or 3.")
    
    # Compute g based on the second categorical variable (ht2)
    if ht2 == 1:
        g = np.cos(x1) + np.cos(x2 * 2) + np.cos(x3)
    elif ht2 == 2:
        g = np.cos(x1) + np.cos(x2 * 2) + np.cos(x3)
    elif ht2 == 3:
        g = np.cos(x1 * 2) + np.cos(x2) + np.cos(x3)
   # else:
    #    raise ValueError("Invalid value for ht2. Expected 1, 2, or 3.")
    
    # Compute h based on the third categorical variable (ht3)
    if ht3 == 1:
        h = np.sin(x1) + np.sin(x2 * 2) + np.sin(x3)
    elif ht3 == 2:
        h = np.sin(x1) + np.sin(x2 * 2) + np.sin(x3)
    elif ht3 == 3:
        h = np.sin(x1 * 2) + np.sin(x2) + np.sin(x3)
    #else:
     #   raise ValueError("Invalid value for ht3. Expected 1, 2, or 3.")
    
    # Compute the final result as f + g + h
    y = f + g + h
    
    # Return the result as a numpy array
    return np.array([y], dtype=float)

# Example usage:
ht_list = [1, 2, 3]  # Categorical inputs
X = [0.5, 0.3, 0.7]  # Continuous inputs

result = func3(ht_list, X)
print(result)
