rm(list=ls())
#------------------------------------------------------------------------------------
#package needed
library(lhs)
library(laGP)
library('nloptr')
library(rgenoud)
#------------------------------------------------------------------------------------
#dimensions
p = 3
q = 3
m=c(3,3,3)
#EzGP package values
tau = sqrt(.Machine$double.eps)
#init and budget
n0=9
N=81
# n0=5*(p+q)
# #N=20*(p+q)
nnew = N-n0
#EI-MC number of contours 
k=10
#size of m_c0
n_M_c0=200
#contour level
a =6.6
#epsilon of m_c0
del = 0.1#epsilon in chapter 3
#hyper par of grouping
epsilon=0.1#del in chapter 3

zvector1=1:m[1]
zvector2=1:m[2]
zvector3=1:m[3]
z_true=as.matrix(expand.grid(zvector1,zvector2,zvector3))
nsim=50
#n0=9
z_true_factorial=matrix(c(1,1,1,2,2,2,3,3,3,1,2,3,1,2,3,1,2,3,1,2,3,2,3,1,3,1,2),n0,3)
#n0=18
# z_true_factorial <- matrix(c(
#   1, 1, 1,
#   1, 2, 2,
#   1, 3, 3,
#   2, 1, 2,
#   2, 2, 3,
#   2, 3, 1,
#   3, 1, 3,
#   3, 2, 1,
#   3, 3, 2,
#   1, 1, 3,
#   1, 2, 1,
#   1, 3, 2,
#   2, 1, 1,
#   2, 2, 2,
#   2, 3, 3,
#   3, 1, 2,
#   3, 2, 3,
#   3, 3, 1), nrow = 18, byrow = TRUE)

#-----------------------------------------------------------------------------
##response with both QQ
computer_simulator=function(xx)#Example function
{
  y=c()
  for(l in 1:nrow(xx)){
    z=xx[l,4:6]
    x=xx[l,1:3]
    
    if(z[1]==1)
      f=x[1]+x[2]^2+x[3]
    else if (z[1]==2)
      f=x[1]^2+x[2]+x[3]
    else if (z[1]==3)
      f=x[1]+x[2]^2+x[3]
    
    if(z[2]==1)
      g=cos(x[1])+cos(x[2]*2)+cos(x[3])
    else if (z[2]==2)
      g=cos(x[1])+cos(x[2]*2)+cos(x[3])
    else if (z[2]==3)
      g=cos(x[1]*2)+cos(x[2])+cos(x[3])
    
    if(z[3]==1)
      h=sin(x[1])+sin(x[2]*2)+sin(x[3])
    else if (z[3]==2)
      h=sin(x[1])+sin(x[2]*2)+sin(x[3])
    else if (z[3]==3)
      h=sin(x[1]*2)+sin(x[2])+sin(x[3])
    
    y[l] <- f+(g+h)
    
  }
  return(y)
  
}
#------------------------------------------------------------------------------------
#Mc0
Data_M_c0=as.matrix(read.csv("~/Desktop/Queens/Research/Thesis/code/contour/R/2024/bookchapter/Ex3/M_c0.csv"))[,2:(p+q+2)]
Data_M_c0_XZ=Data_M_c0[,1:(p+q)]
Data_M_c0_Y=Data_M_c0[,(p+q+1)]
C_t_XZ = Data_M_c0_XZ[Data_M_c0_Y<=(a+del) & Data_M_c0_Y >= (a-del),]
if(is.matrix(C_t_XZ)!=TRUE) C_t_XZ = matrix(C_t_XZ,1,ncol=(p+q))
C_t_Y=computer_simulator(C_t_XZ)
M_c0_M=cbind(C_t_XZ,C_t_Y)
save.image("initial.RData")


#initial data
for(j in 1:nsim){
  x=randomLHS(n0,p)
  z=z_true_factorial
  xz=cbind(x,z)
  y=computer_simulator(xz)
  tradata=cbind(xz,y)
  filename= paste0("tradata","_",j,".csv",sep="")
  write.csv(tradata,file=filename)
}
#build m_c0
#------------------------------------------------------------------------------------
x_M_c0=matrix(NA,nrow=n_M_c0*prod(m),ncol=p)
for(i in 1:prod(m)){
  x_M_c0[(((i-1)*(n_M_c0))+1):(i*n_M_c0),] = randomLHS(n_M_c0,p)
}
z_M_c0=as.matrix(expand.grid(zvector1,zvector2,zvector3))
z_M_c0=apply(z_M_c0,2,rep,n_M_c0)
Data_M_c0_XZ=cbind(x_M_c0,z_M_c0)
Data_M_c0_XZ = as.matrix(Data_M_c0_XZ)
Data_M_c0_Y=computer_simulator(Data_M_c0_XZ)
Data_M_c0=cbind(Data_M_c0_XZ,Data_M_c0_Y)
write.csv(Data_M_c0,"M_c0.csv")
