rm(list=ls())
#------------------------------------------------------------------------------------
#package needed
library(lhs)
library(laGP)
library('nloptr')
library(rgenoud)
#------------------------------------------------------------------------------------
#dimensions
p = 2
q = 2
m=c(3,3)
#init and budget
#contour-optim
n0=9
N=63
#pred
#n0=5*(p+q)
#N=20*(p+q)
nnew = N-n0
#EI-MC number of the countours 
k=10
#size of design space
npred =100
#size of m_c0
n_M_c0=200
#contour level 
a =2.1
#epsilon of m_c0
del = 0.05#epsilon in bookchapter
#hyper par of grouping
epsilon=0.02#del in bookchapter
#iteration
nsim=50
#level of qualitative inputs
zvector1=1:m[1]
zvector2=1:m[2]
z_true=as.matrix(expand.grid(zvector1,zvector2))
z_true_factorial=z_true
#EzGP package paramter
tau = sqrt(.Machine$double.eps)
#-----------------------------------------------------------------------------
##response with both QQ
computer_simulator=function(xx)#Example function
{
  y=c()
  for(l in 1:nrow(xx)){
    z=xx[l,3:4]
    x=xx[l,1:2]
    
    if(z[1]==1)
      f=x[1]+x[2]^2
    else if (z[1]==2)
      f=x[1]^2+x[2]
    else if (z[1]==3)
      f=x[1]^2+x[2]^2
    
    if(z[2]==1)
      g=cos(x[1])+cos(x[2]*2)
    else if (z[2]==2)
      g=cos(2*x[1])+cos(x[2])
    else if (z[2]==3)
      g=cos(x[1]*2)+cos(x[2]*2)

    y[l] <- f+g
    
  }
  return(y)
  
}
#------------------------------------------------------------------------------------
#Mc0
Data_M_c0=as.matrix(read.csv( "~/Desktop/Queens/Research/Thesis/code/contour/R/2024/bookchapter/Ex2/M_c0.csv"))[,2:(p+q+2)]
Data_M_c0_XZ=Data_M_c0[,1:(p+q)]
Data_M_c0_Y=Data_M_c0[,(p+q+1)]
C_t_XZ = Data_M_c0_XZ[Data_M_c0_Y<=(a+del) & Data_M_c0_Y >= (a-del),]
if(is.matrix(C_t_XZ)!=TRUE) C_t_XZ = matrix(C_t_XZ,1,ncol=(p+q))
C_t_Y=computer_simulator(C_t_XZ)
M_c0_M=cbind(C_t_XZ,C_t_Y)
save.image("initial.RData")

#initial data
for(j in 1:nsim){
  x=randomLHS(n0,p)
  z=z_true_factorial
  xz=cbind(x,z)
  y=computer_simulator(xz)
  tradata=cbind(xz,y)
  filename= paste0("tradata","_",j,".csv",sep="")
  write.csv(tradata,file=filename)
}
#M_c0 data
#------------------------------------------------------------------------------------
x_M_c0=matrix(NA,nrow=n_M_c0*prod(m),ncol=p)
for(i in 1:prod(m)){
  x_M_c0[(((i-1)*(n_M_c0))+1):(i*n_M_c0),] = randomLHS(n_M_c0,p)
}
z_M_c0=as.matrix(expand.grid(zvector1,zvector2))
z_M_c0=apply(z_M_c0,2,rep,n_M_c0)
Data_M_c0_XZ=cbind(x_M_c0,z_M_c0)
Data_M_c0_XZ = as.matrix(Data_M_c0_XZ)
Data_M_c0_Y=computer_simulator(Data_M_c0_XZ)
Data_M_c0=cbind(Data_M_c0_XZ,Data_M_c0_Y)
write.csv(Data_M_c0,"M_c0.csv")
