#!/bin/bash

#SBATCH --account=def-cdlin
#SBATCH --time=00:05:00
#SBATCH --mem-per-cpu=1G

module load StdEnv/2020
module load python/3.10
module load gcc r gsl



python3 driver.py Ex1
