from hybridMinimization.__version__ import __version__
name = 'hybridMinimization'
version = __version__