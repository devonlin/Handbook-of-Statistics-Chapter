VERSION = (1, 0, 0)

__version__ = '.'.join(map(str, VERSION))

# alpha/beta/rc tags
__version_suffix__ = ''
