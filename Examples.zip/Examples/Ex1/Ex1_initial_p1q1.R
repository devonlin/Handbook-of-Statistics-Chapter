
###note : in code by mistake I defined del as espilon and epsilon as del.
rm(list=ls())
#------------------------------------------------------------------------------------
#package needed
library(lhs)
library(laGP)
library('nloptr')
library(rgenoud)
#------------------------------------------------------------------------------------
#dimensions
p = 1
q = 1
m=3
#init and budget
#optim_contour
 n0=9
 N=21
#pred
#n0=5*(p+q)
#N=20*(p+q)
nnew=N-n0
#iteration
nsim=30
#size of design space
npred =100
#size of m_c0
n_M_c0=200
#EI-MC number of contours 
k=10
#contour
a =2.2
#epsilon of m_c0
del = 0.05#epsilon in bookchapter
#hyper par of grouping
epsilon=0.05#del in  bookchapter
#EzGP package values
tau=sqrt(.Machine$double.eps)
#qualitative levels
z_true=matrix(1:m,ncol=q)
#------------------------------------------------------------------------------------
#true function
computer_simulator<- function(X)
{ y=c()
for(ic in 1:nrow(X)){
  x1 <- X[ic,1]
  z <- X[ic,2]
  if (z == 1){
    y[ic]=2-cos(2*pi*x1)
  } else { if (z== 2){
    y[ic]=1-cos(4*pi*x1)
  }
    else {if (z == 3){
      y[ic]=cos(2*pi*x1)
    }
    }
  }
}
return(y)
}
#------------------------------------------------------------------------------------
#Mc0
Data_M_c0=as.matrix(read.csv("~/Desktop/Queens/Research/Thesis/code/contour/R/2024/bookchapter/Ex1/M_c0.csv"))[,2:(p+q+2)]
Data_M_c0_XZ=Data_M_c0[,1:(p+q)]
Data_M_c0_Y=Data_M_c0[,(p+q+1)]
C_t_XZ = Data_M_c0_XZ[Data_M_c0_Y<=(a+del) & Data_M_c0_Y >= (a-del),]
if(is.matrix(C_t_XZ)!=TRUE) C_t_XZ = matrix(C_t_XZ,1,ncol=(p+q))
C_t_Y=computer_simulator(C_t_XZ)
M_c0_M=cbind(C_t_XZ,C_t_Y)
save.image("initial.RData")

#initial points generating
for(j in 1:nsim){
  x=randomLHS(n0,p)
  z=rep(1:m,round(n0/m))
  xz=cbind(x,z)
  y=computer_simulator(xz)
  tradata=cbind(xz,y)
  filename= paste0("tradata","_",j,".csv",sep="")
  write.csv(tradata,file=filename)
}

#build M_c0
# ------------------------------------------------------------------------------------
x_M_c0=matrix(NA,nrow=n_M_c0*prod(m),ncol=p)
for(i in 1:prod(m)){
  x_M_c0[(((i-1)*(n_M_c0))+1):(i*n_M_c0),] = randomLHS(n_M_c0,p)
  
}
z_M_c0=rep(1:m,each=n_M_c0)
Data_M_c0_XZ=cbind(x_M_c0,z_M_c0)
Data_M_c0_XZ = as.matrix(Data_M_c0_XZ)
Data_M_c0_Y=computer_simulator(Data_M_c0_XZ)
Data_M_c0=cbind(Data_M_c0_XZ,Data_M_c0_Y)
write.csv(Data_M_c0,"M_c0.csv")

